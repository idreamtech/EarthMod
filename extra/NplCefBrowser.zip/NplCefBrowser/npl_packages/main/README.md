# main
NPL.load("npl_packages/main/")

## Install Guide
```
mkdir npl_packages
cd npl_packages
git clone https://github.com/NPLPackages/main
```