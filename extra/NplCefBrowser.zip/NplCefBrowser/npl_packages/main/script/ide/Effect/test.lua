
NPL.load("(gl)script/ide/PostProcessor.lua");
NPL.load("(gl)script/ide/Effect/motionBlurProcessor.lua");
NPL.load("(gl)script/ide/Effect/filmScratchProcessor.lua");


function Test()
	--commonlib.ps.motionBlur.Initialize();
	--commonlib.ps.EnablePostProcessing(true,commonlib.ps.motionBlur.Process);
	
	--commonlib.ps.filmScratch.Initialize();
	--commonlib.ps.EnablePostProcessing(true,commonlib.ps.filmScratch.Process);

end