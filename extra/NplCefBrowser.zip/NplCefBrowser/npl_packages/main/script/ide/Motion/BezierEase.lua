-- empty file sometimes leads to error, after compiling empty files. 
local function activate()
end