--[[
Title: 
Author(s): Leio
Date: 2010/5/12
Desc: 
Use Lib:
-------------------------------------------------------
NPL.load("(gl)script/ide/IPCBinding/IPCBinding.lua");	
------------------------------------------------------
--]]


